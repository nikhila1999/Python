/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    float height;
    printf("enter your height");
    scanf("%f",&height);
    if (height>150)
    {
        if(height<165)
            printf("%d is dwarf",&height);
        else if(height<190)
            printf("tall");
        else
            printf("abnormal height");
    }
    else
    {
        printf("dwarf");
    }
}




/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int
main ()
{
  int n,i,s=0,a=0,b=1;
  //printf ("enter a number");
  //scanf ("%d", &n);
  printf("%d %d",a,b);
  for(i=1;i<=8;i++)
  {
      s=a+b;
      printf("%d",s);
      a=b;
      b=s;
  }
    return 0;

}

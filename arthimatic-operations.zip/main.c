/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,c;
    printf("enter a number:");
    scanf("%d %d",&a,&b);
    printf("1.add\n2.subtract\n3.multiply\n4.divide\n5.per");
    scanf("%d",&c);
    switch(c)
    {
        case 1:printf("add=%d",a+b);
        break;
        case 2:printf("sub=%d",a-b);
        break;
        case 3:printf("mul=%d",a*b);
        break;
        case 4:printf("div=%d",a/b);
        break;
        case 5:printf("per=%d",a%b);
        break;
        default:
        printf("invalid number selected");
        break;
    }
}
        
        
    
